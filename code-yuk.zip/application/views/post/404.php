<div class="jumbotron container mt-3 text-center">
        <h1 class="display-4" style="font-size: 6rem; margin-top: 5rem;">404 Error</h1>
        <p style="font-size: 1.6rem;" class="mb-5">I think you entered the wrong link ...</p>
        <a href="<?= base_url('post'); ?>" class="btn btn-primary">Back to Home</a>
    </div>